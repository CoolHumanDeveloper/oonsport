<?php 
require("includes/config.php");

///////////////////////////////////////////
//     copyright 2015					///
//     comfort design - medienagntur	///
//     Carsten Ahlers					///
//     Idee oon-sport.de				///
///////////////////////////////////////////



// Ausgabe der Seite 
echo load_template();

mysql_close(DB_LINKED);
 ?>