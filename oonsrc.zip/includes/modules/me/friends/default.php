<?php

$output='<div class="col-md-9 col-sm-12">
    <strong>Freunde</strong><br>
meine Freunde euf oon-sport.de
	</div>';

$content_output=array('TITLE' => 'Freunde',
 'CONTENT' => $sidebar.$output,
 'HEADER_EXT' => '',
  'FOOTER_EXT' => '');

?>