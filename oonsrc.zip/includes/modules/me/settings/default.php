<?php

$output=$sidebar.'<div class="col-md-9 col-sm-12">'.TEXT_SETTINGS_INTRO.'<br>
<br>
under construction...<br>
<br>
<br>
<br>
</div>';


$content_output=array('TITLE' => TEXT_SETTINGS_HEADER,
 'CONTENT' => $output,
 'HEADER_EXT' => '',
  'FOOTER_EXT' => '');
?>