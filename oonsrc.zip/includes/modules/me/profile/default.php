<?php

$output = $sidebar.'<div class="col-md-9 col-sm-12">'.TEXT_PROFILE_INTRO.'</div>';
$content_output = array('TITLE' => 'Profile', 'META_DESCRIPTION' =>'',
 'CONTENT' => $output,
 'HEADER_EXT' => '',
  'FOOTER_EXT' => '');