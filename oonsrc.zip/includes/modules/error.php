<?php 

$content_output = array('TITLE' => "Fehler: ".$_GET['content_value'], 'META_DESCRIPTION' => '', 'CONTENT' => "UPS! Da ist ein Fehler aufgetreten. Sollte sich das Problem nicht von selbst beheben informiere bitte den Administrator dieser Seite.<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
", 'HEADER_EXT' => '', 'FOOTER_EXT' => '');
?>